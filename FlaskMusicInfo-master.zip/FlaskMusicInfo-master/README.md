# FlaskMusicInfo
# IMPORTANT
###     You will have to run ``python -m venv vevn`` in the main directory
